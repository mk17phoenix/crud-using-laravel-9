<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

       

       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
    <body>
   	<div class="container col-md-6">
	<h1 class="text-center text-info">Product Management</h1>
		
	<form class="form-horizontal" action="<?php echo e(url('product/update')); ?>" method="post" enctype="form-data/enctype" >
		<?php echo csrf_field(); ?>
		<div>
			<input type="hidden" name="id" value="<?php echo e($products->id); ?>">
		<label>Name :</label>
		<input type="text" name="name" class="form-control" value="<?php echo e($products->name); ?>" required>
		</div>
		<div>
		<label>SKU :</label>
		<input type="text" name="sku" class="form-control" value="<?php echo e($products->sku); ?>" required>
		</div>
		<div>
		<label>Short Description :</label>
		<textarea name="short_description" class="form-control" required><?php echo e($products->short_description); ?></textarea>
		</div>
		<div>
		<label>Description :</label>
		<textarea name="description" class="form-control" required><?php echo e($products->description); ?></textarea>
		</div>
		<div>
		<label>Images :</label>
		<input type="file" name="images" multiple required>
		</div>
		<div>
		<label>Price :</label>
		<input type="number" name="price" class="form-control" value="<?php echo e($products->price); ?>" required>
		</div>
		<div>
		<label>Status :</label>
		<input type="radio" name="status" value="active" <?php if($products->status=='active'): ?>checked <?php endif; ?>>active
		<input type="radio" name="status" value="inactive" <?php if($products->status=='inactive'): ?>checked <?php endif; ?>>inactive
		</div>
		<button type="submit" class="btn btn-primary">Update</button>
		<hr>
	</form>
    </body>

<?php /**PATH D:\mk17phoenix\resources\views/edit-layout.blade.php ENDPATH**/ ?>